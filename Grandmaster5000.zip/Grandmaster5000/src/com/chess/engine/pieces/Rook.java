package com.chess.engine.pieces;

import com.boardgame.engine.Bitboard;
import com.boardgame.engine.Piece;
import com.boardgame.engine.Position;

/**
 * This class models the Rook piece, which moves according to the rules of chess. 
 * 
 * @author Junaid Mohammed
 * @version February 27, 2010
 */


public class Rook extends Piece {
    private static final long serialVersionUID = -5523276415522998967L;

    public static long getAttackBitmap(long[][] bitboard, Piece piece) {
        long bitmap = Bitboard.getBitmapAtPosition(bitboard, piece.getPosition());
        long result = 0;
        
        int rank = piece.getPosition().getRank() + 1;
        int file = piece.getPosition().getFile();
        
        /* The set of squares, below the Rook, along its rank. */
        for (int i = 1; i < (8 - piece.getPosition().getRank()); i++) {
            result = result | (bitmap << (8 * i));
            
            if (Bitboard.isPositionOccupied(bitboard, new Position(rank, file))) {
                break;
            }
            
            rank++;
        }
        
        rank = piece.getPosition().getRank() - 1;
        file = piece.getPosition().getFile();
        
        /* The set of squares, above the Rook, along its rank. */
        for (int i = 1; i < (piece.getPosition().getRank() + 1); i++) {
            result = result | (bitmap >>> (8 * i));
            
            if (Bitboard.isPositionOccupied(bitboard, new Position(rank, file))) {
                break;
            }
            
            rank--;
        }
        
        rank = piece.getPosition().getRank();
        file = piece.getPosition().getFile() + 1;
        
        /* The set of squares, right of the Rook, along its file. */
        for (int i = 1; i < (8 - piece.getPosition().getFile()); i++) {
            result = result | (bitmap << (1 * i));
            
            if (Bitboard.isPositionOccupied(bitboard, new Position(rank, file))) {
                break;
            }
            
            file++;
        }
        
        rank = piece.getPosition().getRank();
        file = piece.getPosition().getFile() - 1;
        
        /* The set of squares, left of the Rook, along its file. */
        for (int i = 1; i < (piece.getPosition().getFile() + 1); i++) {
            result = result | (bitmap >>> (1 * i));
            
            if (Bitboard.isPositionOccupied(bitboard, new Position(rank, file))) {
                break;
            }
            
            file--;
        }
        
        return result;
    }
}