package com.chess.grandmasterchess2011.view;

import java.awt.Color;

/**
 * Write a description of class GraphicalChessGame here.   
 * 
 * @author (Junaid Mohammed) 
 * @version (a version number or a date)
 */

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.boardgame.engine.Bitboard;
import com.boardgame.engine.ChessGameModel;
import com.boardgame.engine.Piece;
import com.boardgame.engine.Position;

public class ChessGraphicalView implements Observer {  
	
	private ChessGameModel model;
	
	private final int width;
    private final int height;
	
    private JFrame frame;
    private Container mainContainer;
	private ActionListener act;	
	
	private PositionButton[][] boardGrid;
		
	private final int GRID_WIDTH;
	private final int GRID_HEIGHT;
		
	private static final int FRAME_WIDTH = 500;//(840-6-200);
	private static final int FRAME_HEIGHT = 500; //(640-200); //6 is extra spacing
	
	private static final Dimension FRAME_SIZE = new Dimension(FRAME_WIDTH, FRAME_HEIGHT);
		
	private static final int FRAME_FULL_SCREEN_WIDTH = 1050;
	private static final int FRAME_FULL_SCREEN_HEIGHT = 750;
			
	private static final String GAME_TITLE = "Grand Master Chess 2011";
	private static final String AUTHOR = "Junaid Mohammed";
	private static final String TITLE = GAME_TITLE + " by " + AUTHOR;
	
	private LabelHandler labelHandler;
	private MainMenuView mainMenuView;


	/**
	 * 
	 * @param model
	 */
    public ChessGraphicalView(ChessGameModel model) {  
		this.model = model;
    	width = 8;
    	height = 8;
    	
    	
    	GRID_WIDTH = width + 6;
    	GRID_HEIGHT = height + 2;  	             
    	
    	boardGrid = new PositionButton[width][height];
    	
		//backgroundHandler = new BoardBackgroundHandler(model.getBoard());

    	//highlightHandler = new HighlightHandler(model, this); //depends on the boardGrid
    	//takeView = new TakenChessPieceView(model);
    	//soundManager = new CaptureSoundManager();    	
    	//model.getCaptureManager().addObserver(soundManager);

    	mainMenuView = new MainMenuView(this);
    	labelHandler = new LabelHandler();
    	
    //	CheckManager checkManager = model.getCheckManager();
    	//checkHandler = new CheckHandler(checkManager, mainContainer);
    //	checkManager.addObserver(checkHandler);
    //	
    	createWindowFrame(); 	                  
    }
    
    private void createWindowFrame(){    	
        frame = new JFrame(TITLE);
        frame.setIconImage((new ImageIcon(getClass().getResource("/resources/j-icon.jpg")).getImage()));    	 
        mainContainer = frame.getContentPane();
                
        frame.addWindowListener
            (new  WindowAdapter()
                {
                    public void windowClosing(WindowEvent e)
                    {
                        System.exit(0);
                    }
                }
            ); 
        frame.setSize(FRAME_WIDTH , FRAME_HEIGHT);
        addGrid();
        frame.setVisible(true);   
    }
    
    public void addPlayerSetupListener(ActionListener act){
    	mainMenuView.addPlayerSetupListener(act);
    }

    
    public void addGridListener(ActionListener act){
    	this.act = act;
    	//addGrid();
    }
    
    /**
     * adds PositionButtons to the container, and adds ActionListeners to them
     */
    private void addGrid(){       
    	//intro();        	
    	//menu();     	
    }    
    
	public Dimension getFrameSize(){
		return FRAME_SIZE;
	}
    
    private void intro(){
    	mainContainer.setLayout(new FlowLayout());
        mainContainer.validate();

		Image image = Toolkit.getDefaultToolkit().createImage(getClass().getResource("/resources/pawn-pawn.gif"));		
		JLabel label = new JLabel(new ImageIcon(image));
		mainContainer.add(label);
        mainContainer.validate();
        
        try {
        	Thread.sleep(5000L);    // one second
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
    }
    
    private void menu(){        
    	//TODO instantiate the diff view objects and have a main view, 
    	//so u dont have to keep removing buttons
    	
        mainContainer.setLayout(null);      
        
        JPanel panelBgImg = mainMenuView.getMainPanel();        
        mainContainer.add(panelBgImg);
        panelBgImg.setBounds(0, 0, FRAME_WIDTH, FRAME_HEIGHT);
                
        JPanel menuPanel = mainMenuView.buttons();            
        panelBgImg.add(menuPanel);           
        panelBgImg.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 250));        
        mainContainer.validate();

       // frame.setResizable(false);    
    }
    
    public void startGame(){
    	mainContainer.removeAll();  	
    	mainContainer.setLayout(new GridLayout(GRID_HEIGHT, GRID_WIDTH));//ROWs,COLs!!!!!!!
        mainContainer.validate();

        setLogo();
        setColumnLabels();
        setLogo();
   //     setTaken(0);        
    	
        addBoardGrid();           
               
        setLogo();
        setColumnLabels();
        setLogo();
   //     setTaken(9);
        
        mainContainer.validate();
    }       
        
//    public BoardBackgroundHandler getBackgroundHandler(){
//    	return this.backgroundHandler;
//    }
//    
    public PositionButton[][] getBoard(){
    	return this.boardGrid;
    }
    
    private void addBoardGrid(){
    	Piece piece;
        ImageIcon icon;
        Position pos;  
        PositionButton button; 
           
     //   System.out.println(""+ model.getBoard().toString());
        
        for(int col = 0; col < width; col++) {         	 
        	setRowLabel(col);
            for(int row = 0; row < height; row++) {                   
            	pos = new Position(col, row);            	
            	
            	//System.out.println("	BOARDVIEW: "+ Bitboard.getString(Bitboard.getBitmap(model.getBitboard())));

            	
                piece = Bitboard.getPieceAtPosition(model.getBitboard(), pos);
                
                if(piece != null){
                    icon = new ImageIcon(piece.getImage());
                }
                else{
                	icon = new ImageIcon();
                }
                
                JButton oldButton = boardGrid[col][row]; //before updating board
            	button = new PositionButton(icon, pos);
            	
            	//backgroundHandler.handleBoardColor(oldButton, button, pos);                   
            	
                button.addActionListener(act);


                //column is offet extra to the right because of labels
                boardGrid[col][row] = button;
                mainContainer.add(button);
            }
        	setRowLabel(col);
            //setTaken(row+1);
        }                        	
    }    
        
//    private void setTaken(int row){
//    	JButton[] buttons = takeView.getTakenButton(row);
//        
//    	for(JButton button: buttons){
//            mainContainer.add(button);
//    	}
//    }
        
    private void setRowLabel(int row){
    	JButton button = labelHandler.getRowLabel(row);
    	mainContainer.add(button);    	
    }
    
    private void setLogo(){
    	JButton button = labelHandler.getLogo();  	
        mainContainer.add(button);	
    }
    
    private void setColumnLabels(){
    	JButton[] buttons = labelHandler.getColumnLabels();
    	for(JButton button: buttons){
            mainContainer.add(button);    		
    	}
    }
   
    /**
     * Updates the container after each move
     */
    private void updateContainer() {   
    	//mainContainer.removeAll();                    
        startGame();  
    }

    private void handleFightAnimation(){
   		    	
        JFrame fightFrame = new JFrame("Fight");               
        Container container = fightFrame.getContentPane();
    	container.setLayout(new FlowLayout());
         
        fightFrame.setSize(300, 300);      
        fightFrame.setVisible(true);     

		Image image = Toolkit.getDefaultToolkit().createImage(getClass().getResource("/resources/pawn-pawn.gif"));		
		JLabel label = new JLabel(new ImageIcon(image));               
        container.add(label);
		container.validate();
		       
//    	try {
//    		Thread.sleep(5000L);    // one second
//    	}
//    	catch (Exception e) {
//    		e.printStackTrace();
//    	}  	  

    	
        //fightFrame.setVisible(false);         

    }

	@Override
	public void update(Observable o, Object obj) {
		 //  System.out.println("Update called");

		
		if(o instanceof ChessGameModel){
			ChessGameModel chessModel = (ChessGameModel) o;
			if(chessModel == model){

				//System.out.println("REACHED");
				//if(obj.equals("ready")){
				updateContainer();
				//}

//				if(obj instanceof String){
//					String message = (String) obj;
//					handleMessage(message);
//				}
				if(obj instanceof Piece){
					Piece selectedHighlightPiece = (Piece) obj;
					//highlightHandler.setHighlightPiece(selectedHighlightPiece);				
					mainContainer.validate();
				}
				else if(obj instanceof String){
					String msg = (String) obj;
					if(msg.equals(ChessGameModel.LAST_MOVE_MESSAGE)){
						//highlightHandler.setLastMove();				
						mainContainer.validate();		
					}
				}
				//updateContainer();
				

			}
		}
	}    
	
//	private void handleMessage(String message){
//		if(message.equals("CHECK!") || message.equals("DOUBLE CHECK!")){
//			handleCheck(message);
//		}		
//		else if(message.equals("CHECK MATE!!")){
//			handleFightAnimation();
//		}
//		else if(message.equals("disable")){
//			//selectedHighlightPiece = null;
//		}
//	}
//	
//	private void handleCheck(String message){
//		Toolkit.getDefaultToolkit().beep();
//		JOptionPane.showMessageDialog(mainContainer, message);
//	}


    
}

