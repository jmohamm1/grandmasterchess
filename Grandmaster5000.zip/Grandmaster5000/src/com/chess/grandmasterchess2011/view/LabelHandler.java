package com.chess.grandmasterchess2011.view;

import java.awt.Color; 

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class LabelHandler {

	private static final Color BLACK_LABEL_BUTTON = new Color(0,0,0);

	private static final int NUM_LABELS = 8;
	
	public JButton[] getColumnLabels(){
    	JButton[] colButtons = new JButton[NUM_LABELS];   
    	int colIndex;
    	JButton button;
    	for(char col = 'a'; col <= 'h'; col++){             
            colIndex = (col - 'a');    		
    		
            button = new JButton("" + col); 
            button.setEnabled(false);
            button.setBackground(BLACK_LABEL_BUTTON);        	

            colButtons[colIndex] = button; 
            //mainContainer.add(colButtons);
        }
    	return colButtons;
	}
//	
//    private void setColumnLabels(){
//    	JButton button;   
//    	int colIndex;
//    	for(char col = 'a'; col <= 'h'; col++){               	
//            button = new JButton("" + col); 
//            button.setEnabled(false);
//        	button.setBackground(BLACK_LABEL_BUTTON);        	
//
//            colIndex = (col - 'a');
//            colLabelGrid[colIndex] = button; 
//            mainContainer.add(button);
//
//        }   	
//    }
    
    public JButton getRowLabel(int row){
    	JButton button;  
    	button = new JButton("" + (NUM_LABELS - row));    	
    	button.setEnabled(false);
    	button.setBackground(BLACK_LABEL_BUTTON); 
    	return button;
    }
    
//    private void setRowLabel(int row){
//    	JButton button;  
//    	button = new JButton("" + (DIM.height - row));    	
//    	button.setEnabled(false);
//    	button.setBackground(BLACK_LABEL_BUTTON);      	
//    	rowLabelGrid[row] = button; 
//    	mainContainer.add(button);    	
//    }
    
    
    public JButton getLogo(){
    	Class c = getClass();
    	ImageIcon icon = new ImageIcon(c.getResource("/resources/j-icon.jpg"));    	 
    	JButton button = new JButton(icon); 
    	button.setBackground(BLACK_LABEL_BUTTON);    	
        //mainContainer.add(button);
    	return button;
    }
}
