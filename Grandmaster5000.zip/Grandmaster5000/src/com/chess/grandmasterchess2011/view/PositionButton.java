package com.chess.grandmasterchess2011.view;

/**
 * Write a description of class ChessButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import javax.swing.ImageIcon;
import javax.swing.JButton;

import com.boardgame.engine.Position;

public class PositionButton extends JButton
{
    /**
	 * 
	 */
	private static final long serialVersionUID = -5280434519491634892L;
	
	// instance variables - replace the example below with your own
    private Position pos;
    
    /**
     * Constructor for piece represented by string label
     */
    public PositionButton(String label, Position pos)
    {
        super(label);
        this.pos = pos;    
    }

    /**
     * Constructor for piece represented by icons
     */
    public PositionButton(ImageIcon icon, Position pos)
    {
        super(icon);
        this.pos = pos;
    }          
    
    /**
     * accessor for position
     * @return Position
     */
    public Position getPosition()
    {
        return pos;
    }    
}
