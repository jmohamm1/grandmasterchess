package com.chess.grandmasterchess2011.view;

import java.awt.Color; 
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class MainMenuView implements ActionListener {

	public static final String ONE_PLAYER = "ONE PLAYER";
	public static final String TWO_PLAYERS = "TWO PLAYERS";
	public static final String TWO_COMPUTERS = "TWO COMPUTERS";
	public static final String LOAD_GAME = "LOAD GAME";
	public static final String OPTIONS = "OPTIONS";
	public static final String ABOUT = "ABOUT";
		
	private final Dimension FRAME_SIZE;
	private ChessGraphicalView view;
	
	private Image backgroundImage;
	private ActionListener playerSetupListener;
	
	public MainMenuView(ChessGraphicalView view){
		this.view = view;
		this.FRAME_SIZE = view.getFrameSize();
        backgroundImage = new ImageIcon(getClass().getResource("/resources/background.jpg")).getImage();
	}
	
	public void addPlayerSetupListener(ActionListener act){
		this.playerSetupListener = act;
	}
	
	public JPanel getMainPanel(){
		  JPanel panelBgImg = new JPanel() {
	            public void paintComponent(Graphics g) 
	            {
	                Dimension size = new Dimension(FRAME_SIZE.width, FRAME_SIZE.height);
	                setPreferredSize(size);
	                setMinimumSize(size);
	                setMaximumSize(size);
	                setSize(size);
	                setLayout(null);
	                g.drawImage(backgroundImage, 0, 0, null);
	            } 
	        };
	        return panelBgImg;
	        
	}
	
	public JPanel buttons(){
        JPanel menuPanel = new JPanel();
        
    	ImageIcon icon = new ImageIcon(getClass().getResource("/resources/j-icon.jpg"));    	 
    	JLabel logo = new JLabel(icon); 
    	
        //JLabel title = new JLabel("MENU");        
        JButton onePlayer = new JButton(ONE_PLAYER);
        onePlayer.addActionListener(this);
        JButton twoPlayer = new JButton(TWO_PLAYERS);
        twoPlayer.addActionListener(this);
        JButton twoComputers = new JButton(TWO_COMPUTERS);
        twoComputers.addActionListener(this);        
        JButton load = new JButton(LOAD_GAME);
        load.addActionListener(this);      
        JButton options = new JButton(OPTIONS);
        options.addActionListener(this);       
        JButton about = new JButton(ABOUT);
        about.addActionListener(this);
  
        JPanel logoPanel = new JPanel();
        logoPanel.add(logo);
        logoPanel.setBackground(Color.YELLOW);

        //menuPanel.add(title);
        menuPanel.add(onePlayer);
        menuPanel.add(twoPlayer);
        menuPanel.add(twoComputers);
        menuPanel.add(load);
        menuPanel.add(options);
        menuPanel.add(about);

        //panelContent.setBackground(Color.GRAY);
        //panelContent.setBorder(new LineBorder(Color.WHITE));
        int numButtons = 6;
        int numColumns = 1;
        GridLayout gridLayout = new GridLayout(numButtons, numColumns);
        gridLayout.setVgap(2);        
        menuPanel.setBackground(Color.YELLOW);
        menuPanel.setBorder(new LineBorder(Color.WHITE));
        
        menuPanel.setLayout(gridLayout);         
        return menuPanel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//JButton button = (JButton) e.getSource();
		//String label = button.getText();
		playerSetupListener.actionPerformed(e);
		
	}
}
