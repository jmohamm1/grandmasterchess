package com.boardgame.engine;

/**
 * @author Junaid Mohammed       
 * @version March 18, 2010
 */

import java.util.Observable;

import com.boardgame.engine.managers.TurnManager;
import com.chess.grandmasterchess2011.view.ChessGraphicalView;

/**
 * 
 * @author Junaid
 *
 */
public class ChessGameModel extends Observable{
	
	public static final String LAST_MOVE_MESSAGE = "lastturn";
	//public static final String DISABLE_MESSAGE = "disable";
	
    
//    private ChessPlayer whitePlayer;
//    private ChessPlayer blackPlayer;
    
    private long[][] bitboard;
        
    private boolean isGameStarted;
   // private MoveIterator moveIterator;
        
    /**
     * Constructor
     */
	public ChessGameModel() {
    	bitboard = Bitboard.generateBitboard();
  
        
        this.turnManager = new TurnManager();
    }

    public long[][] getBitboard(){
    	return this.bitboard;
    }
//    public void subscribeToCheckManager(Observer o){
//    	checkManager.addObserver(o);
//    }
    
//    public void subscribeToCaptureForecaster(Observer o){
//    	captureForecaster.addObserver(o);
//    }
    

	public boolean isGameStarted(){
		return this.isGameStarted;
	}
	
	public void setGameStart(boolean start){
		this.isGameStarted = start;
	}

    
         
    
//    public boolean isPlayerInCheck(boolean color){
//    	return checkManager.isPlayerInCheck(color);
//    }
//    
//    public boolean getPlayerCheckStatus(boolean color){
//    	return checkManager.getPlayerCheckStatus(color);
//    }	
	
//	public boolean canCastle(Move move){
//		return castleManager.canCastle(move); 
//	}
    
    private void handleEndGame(){    	
    	System.out.println("GAME OVER!");
    	gameOverFlag = true;
    }
    
    private boolean gameOverFlag;
        
    public void run(Move move){  
    //	System.out.println("	MOVE: "+move);
    	//System.out.println("	BOARD: "+ Bitboard.getString(Bitboard.getBitmap(bitboard)));
    	
		if(gameOverFlag==true){
			return;
		}
		
    	if(move == null){
    		handleEndGame();
    		return;
    	}
    	Position initialPos = move.getX();
    	Position finalPos = move.getY();
    	
    	Piece initialPiece = Bitboard.getPieceAtPosition(bitboard, initialPos);
    	bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, initialPos);
    	

    	Piece finalPiece = Bitboard.getPieceAtPosition(bitboard, finalPos);
    	
    	if(finalPiece != null){
    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, finalPiece, finalPos);
    	}

//    	Piece finalPiece = board.getPieceAtPosition(finalPos);

    	bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, finalPos);
    	
    	
//		System.out.println("Data Scientist thinking...");
//		Move aiMove = ai.searchForMove(bitboard,0);
//		System.out.println("Best move: "+aiMove);
		
    	
//    	Piece initialPiece = board.getPieceAtPosition(initialPos);
//    	Piece finalPiece = board.getPieceAtPosition(finalPos);
//		if(initialPiece == null){
//			System.out.println(initialPos);
//			throw new IllegalArgumentException("init piece cannot be null");
//		}
//		
//		//we get here because the move is legal
//		//capture the piece and add to taken list
//		captureManager.handleCapturePiece(finalPiece);			
//		
//		if(castleManager.checkForCastle(move) == false){
//			board.movePiece(move);
//			moveHistoryManager.addMove(move);	
//
//			pawnPromoManager.handlePawnPromotion(initialPiece, finalPos);			
//			castleManager.handleHasMoved(initialPiece);			
//		}				
//		
//		boolean opponentboolean = turnManager.getOpponentsTurn();
//		if(checkManager.evaluateCheckState(opponentboolean)){
//			//check for human checkmate here..
//			if(isCheckRecoverable(opponentboolean) == false){
//				handleEndGame();
//			}
//		}

    	
		System.out.println("Performance: "+performanceCount);
		//printMoves();		
    	performanceCount = 0;

		turnManager.toggleTurn();
		notifyView();
    }
    
//    private void printMoves(){
//		ArrayList<Piece> pieces = getPlayer(turnManager.getOpponentsTurn()).getCopyPieces();
//		System.out.print("[");
//		for(Piece piece : pieces){
//			String pieceName = AIChessPieceValue.decodeValue(piece);
//			System.out.print(pieceName+":");
//			for(Move m : generatePossibleMoves(piece)){
//				System.out.print(m + "|");
//			}		
//			System.out.print("\n");
//		}
//		System.out.println("]");	
//    }

    
    public void notifyView(){
		setChanged();
		notifyObservers(LAST_MOVE_MESSAGE); 
		setChanged();

		notifyObservers();
	//	checkManager.notifyCheckView();		
    }
    
//    public boolean canMoveRecoverCheck(Move move){
//    	Piece piece = board.getPiece(move.getInitialPosition());
//    	boolean color = piece.getColor();
//    	moveIterator.makeMove(move);
//    	if(checkManager.isPlayerInCheck(color)){
//    		moveIterator.revertMove();
//    		return false;
//    	}
//    	moveIterator.revertMove();
//    	return true;
//    }
    
    private int performanceCount = 0;
//    public ArrayList<Move> generatePossibleMoves(Piece piece){
//    	performanceCount++;
//    	ArrayList<Move> possibleMovesList = new ArrayList<Move>();    	
//    	ArrayList<Position> posList = ((ChessBoard) board).generatePossibleMoves(piece);
//    	boolean color = piece.getboolean();
//    	
//    	for (Position pos : posList) {
//    		Move move = new Move(piece.getPosition(), pos);    	    		
//    		if(recoverCheckMove(move, color)){
//    			continue;
//    		}    	   		
//    	   	if(checkKingThreathen(move, color)){
//    	   		continue;
//    	   	}  	    		
//    		//if everything above passes then add possible move to list
//    		possibleMovesList.add(move);    		
//        }
//    	return possibleMovesList;
//    }
//    
//    private boolean recoverCheckMove(Move move, boolean color){
//       	//when in check, can only move pieces that will recover from check
//		boolean isInCheck = getPlayerCheckStatus(color);
//		if(isInCheck){
//			if(canMoveRecoverCheck(move) == false){
//				return true;
//			}
//		} 
//		return false;
//    }
    
//    private boolean checkKingThreathen(Move move, boolean color){
//    	//cannot move piece that will put king in check
//    	moveIterator.makeMove(move);    
//    	if(isPlayerInCheck(color)){    	   		
//    		moveIterator.revertMove();
//    		return true;
//    	}
//    	moveIterator.revertMove();
//    	return false;
//    }
    
//	public boolean isCheckRecoverable(boolean color){		
//		List<Move> moves = possibleMovesForPlayer(color);		
//		return (moves.size() != 0);
//	}
	
	/**
	 * 
	 * @param color
	 * @return
	 */
//	public ArrayList<Move> possibleMovesForPlayer(boolean color){
//		Player player = getPlayer(color);
//		ArrayList<Piece> pieces = player.getCopyPieces();
//		
//		ArrayList<Move> moves = new ArrayList<Move>();
//		for (Piece currentPiece: pieces){
//			moves.addAll(generatePossibleMoves(currentPiece));
//		}
//		return moves;
//	}
//	
    /**
     * Prints the list of possible moves
     * @return new ArrayList<Position> list if ChessPiece is added
     */
//    public ArrayList<Move> printPossibleMoves(Piece piece)
//    {
//        ArrayList<Move> updatedPosList = generatePossibleMoves(piece);           
//        System.out.print("Possible moves: ");                                               
//        if(updatedPosList.isEmpty()) {
//            System.out.print("[None] \n");
//        }
//        else {
//            System.out.print(updatedPosList + "\n");                   
//        }  
//        return updatedPosList;
//    }
	    
    protected void alert(String s) {
        System.out.println(s);
    }    
    
    protected Position selectedPos;
    
    protected TurnManager turnManager;    

    
//    public ChessPlayer getPlayer(boolean color){
//    	return alivePieceManager.getPlayer(color);
//    }
    
//    public void updatePiece(Piece piece){
//    	alivePieceManager.updatePiece(piece);
//    }
    
//    public Piece getPiece(Piece piece){
//    	return alivePieceManager.getPiece(piece);
//    }
//        
//    public CaptureManager getCaptureManager(){
//    	return this.captureManager;
//    }
//    
    public boolean getTurn(){
    	return turnManager.getTurn();
    }
    
    public int getNumTurn(){
    	return turnManager.getNumTurn();
    }
    
        
    public void pieceSelected(Piece pieceSelected){
    	setChanged();
    	notifyObservers(pieceSelected);
    }


}