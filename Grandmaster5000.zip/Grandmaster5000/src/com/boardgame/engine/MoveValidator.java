package com.boardgame.engine;

import java.util.LinkedList;

import com.boardgame.ai.MoveGenerator;
import com.chess.engine.pieces.King;


/**
 * 
 * @author Junaid
 *
 */
public class MoveValidator {

	private Move move;
	private Position initialPosition;
	private Position finalPosition;
	
	private Position selectedPos;
	private Piece pieceSelected;
	private int pieceSelectedColor;
	private boolean turn;
	
	private boolean initialMove;
	private ChessGameModel model;
	
	/**
	 * 
	 * @param model
	 */
	public MoveValidator(ChessGameModel model){
		this.model = model;
		initialMove = false;
	}
	
	public Move getMove(){
		return this.move;
	}
	
	private boolean isPieceSelectedEmpty(){
		return (pieceSelected == null);
	}
	
	private boolean convertColorToBoolean(int color){
		if(color==0)
		{
			return false;
		}
		else if (color ==1){
			return true;
		}
		return false;
	}
	
	private boolean isOwnPieceSelected(){
		if(isPieceSelectedEmpty()){
			return false;
		}
		
		//SELECTED YOUR OWN PIECE
		if(convertColorToBoolean(pieceSelectedColor)==(turn)){
			return true;
		}
		return false;
	}
	
	private boolean isOpponentPieceSelected(){
		if(isPieceSelectedEmpty()){
			return false;
		}		
		if((convertColorToBoolean(pieceSelectedColor) ==(turn)) == false){
			//SELECTED OPPONENTS PIECE
			return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @param selectedPos
	 * @return
	 */
	private boolean invalidInitial(){	
		if(initialMove == false){
			if(isPieceSelectedEmpty()){
				alert("There is no piece at that coordinate!");
				return true;
			}
			if(isOpponentPieceSelected()){
				alert("Wrong piece selected!");			
				return true;
			}			
		}		
		if(isOwnPieceSelected()){
			alert("Valid initial move.");
			initialPosition = selectedPos;	

			model.pieceSelected(pieceSelected);
		//	model.printPossibleMoves(pieceSelected);
			return false;
		}		
		return false;
	}
		
	/**
	 * 
	 * @param selectedPos
	 * @return
	 */
	private boolean validateFinal(){
		//LANDING ON EMPTY OR CAPTURING	
		//List<Move> possibleMoves = pieceSelected.getAttackBitmap();
		long[][] bitboard = model.getBitboard();
		Piece getPiece = Bitboard.getPieceAtPosition(bitboard,initialPosition);
		long attackBitmap = Bitboard.getAttackBitmap(bitboard,getPiece);
		System.out.println("Attack Bitmap: "+attackBitmap);
		
		LinkedList<Move> moves = MoveGenerator.generateMovesForPiece(bitboard,getPiece);
		System.out.println(moves);
		
		
		Move checkMove = new Move();
		checkMove.setX(initialPosition);
		checkMove.setY(selectedPos);
		
		
		
		boolean valid = Bitboard.isPositionAttacked(attackBitmap, selectedPos);
		System.out.println("Valid?: "+valid);
		
		if(valid){
			
			alert("Valid move.");
			finalPosition = selectedPos;
			move = new Move(initialPosition, finalPosition);										
			return true;
		}
	
//		if(possibleMoves.contains(new Move(initialPosition, selectedPos))){
//			alert("Valid move.");
//			finalPosition = selectedPos;
//			move = new Move(initialPosition, finalPosition);			
//			return true;
//		}		
		alert("Illegal move!");

		
		/**if(isPieceSelectedEmpty() || isOpponentPieceSelected()){			

			if (board.getPiece(initialPosition).canMoveTo(selectedPos) == false) {
				alert("Illegal move!");
				return false;
			}
			
			alert("Valid move.");
			finalPosition = selectedPos;
			move = new Move(initialPosition, finalPosition);
			return true;
		}*/
		return false;
	}
	
	private void gatherInfo(Position selectedPos){
		this.selectedPos = selectedPos;
		this.pieceSelected = Bitboard.getPieceAtPosition(model.getBitboard(),selectedPos); 
		if(isPieceSelectedEmpty()){
			this.pieceSelectedColor = -1;
		}
		else{
			this.pieceSelectedColor = pieceSelected.getColor();
			System.out.println("MoveValidator: gathered color "+pieceSelected.toString());
		}
		this.turn = model.getTurn();
	}
	
	private void resetMove(){
		this.initialPosition = null;
		this.finalPosition = null;
		initialMove = false;
	}
	
	/**
	 * Validates selection on board
	 * @param selectedPos
	 * @return true if move is created, else false
	 */
	public boolean isValidMove(Position selectedPos){
		gatherInfo(selectedPos);
		
		if(invalidInitial()){
			return false;
		}		
		initialMove = true;
		
		if(validateFinal()){
			resetMove();
			return true;
		}

		return false;
	}	
	
    protected void alert(String message) {
        System.out.println(">>>" + message);
    }
    
    public boolean getInitialMove(){
    	return initialMove;
    }
}
