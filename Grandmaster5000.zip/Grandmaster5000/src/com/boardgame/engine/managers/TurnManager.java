package com.boardgame.engine.managers;

 
public class TurnManager {
    public static final boolean WHITE_TURN = true;
    public static final boolean BLACK_TURN = false;
    public static final boolean DEFAULT_TURN = WHITE_TURN;
    
    private int numTurn;
    
	protected boolean turn;

	public TurnManager(){
        turn = DEFAULT_TURN; 
        numTurn = 0;
	}    
	
	@Override
    public String toString() {
        String color = "";
        
        if(turn == (WHITE_TURN)){
        	color = "White";
        }
        else if(turn == (BLACK_TURN)){
            color = "Black";
        }
        else{
        	color = "null";
        }
        return color + "'s turn";                
    }   
    
    public boolean getTurn(){
    	return this.turn;
    }
    
    public int getNumTurn(){
    	return this.numTurn;
    }
    
    public boolean getOpponentsTurn(){
    	return !(this.turn);
    }

    public void toggleTurn() {
        this.turn = getOpponentsTurn();
        numTurn++;
        System.out.println(this);
    }  
}
