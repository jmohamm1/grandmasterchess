package com.boardgame.ai;

import java.util.LinkedList;

import com.boardgame.engine.Bitboard;
import com.boardgame.engine.Move;
import com.boardgame.engine.Piece;
import com.boardgame.engine.Position;

public class MoveGenerator {
    
    public static LinkedList<Move> generateMovesForPiece(long[][] bitboard, Piece piece) {
        LinkedList<Move> result = new LinkedList<Move>();
        long bitmap;
        
        bitmap = Bitboard.getAttackBitmap(bitboard, piece);
        
        while (bitmap != 0) {
            Position destination = Bitboard.getPositionFromBitmap(bitmap);
            Move move = new Move();
            
            move.setX(piece.getPosition());
            move.setY(destination);
            
            result.add(move);
            
            bitmap = bitmap & ~Bitboard.getMaskAtPosition(destination);
        }
        
        return result;
    }
    
    public static LinkedList<Move> generateMovesForColor(long[][] bitboard, int color) {
        LinkedList<Move> result = new LinkedList<Move>();
        
        for (int i = 0; i < 6; i++) {
            long bitmap = Bitboard.getBitmap(bitboard, color, i);
            
            while (bitmap != 0) {
                Piece origin = new Piece(color, i);
                
                origin.setPosition(Bitboard.getPositionFromBitmap(bitmap));
                
                result.addAll(MoveGenerator.generateMovesForPiece(bitboard, origin));
                
                bitmap = bitmap & ~Bitboard.getMaskAtPosition(origin.getPosition());
            }
        }
        
        return result;
    }
}