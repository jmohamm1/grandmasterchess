package com.boardgame.ai;

import java.util.LinkedList;

import com.boardgame.engine.Bitboard;
import com.boardgame.engine.ChessGameModel;
import com.boardgame.engine.Move;
import com.boardgame.engine.Piece;

public class Search {
    private int depth;
    private long nodes;
    private ChessGameModel model;
    private double score;
    
    public Search(ChessGameModel model) {
        this(model,3);
    }
    
    public Search(ChessGameModel model, int depth) {
    	this.model = model;
        this.depth = depth;
        this.nodes = 0;        
    }
    
    public Move searchForMove(long[][] bitboard, int color) {
    	LinkedList<Move> availableMoves = MoveGenerator.generateMovesForColor(bitboard, color);      
    	
    	for (Move move : availableMoves) {
    		
    		Piece initialPiece = Bitboard.getPieceAtPosition(bitboard, move.getX());
    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getX()); 
    		Piece finalPiece = Bitboard.getPieceAtPosition(bitboard, move.getY());        	
    		if(finalPiece != null){
    			bitboard = Bitboard.unsetPieceAtPosition(bitboard, finalPiece, move.getY());
    		}
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getY());
    		
    		score = alphaBetaMin(bitboard, Search.invertColor(color), Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, this.depth - 1);
    		move.setScore(score);

    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getY()); 
    		if(finalPiece != null){
    			bitboard = Bitboard.setPieceAtPosition(bitboard, finalPiece, move.getY());
    		}        	
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getX());
    		    		
			
    	}
       

    	double bestScore = availableMoves.getFirst().getScore();
    	Move result = availableMoves.getFirst();
    	for (Move move : availableMoves) {
    		System.out.println("Move: "+ move+" score: "+move.getScore());
    		double score = move.getScore();
    		
    		if(score == 0){ //check
    			continue;
    		}
    		
    		if (score > bestScore) {
    			bestScore = move.getScore();
    			result = move;
    		}
    	}

    	//System.out.print("Move: " + result + ", Nodes: " + this.nodes + "\n");

    	return result;
    }   
    
    private double alphaBetaMax(long[][] bitboard, int color,  double alpha, double beta, int depthleft ) {
    	this.nodes++;
    	if ( depthleft == 0 ) return Evaluator.evaluate(bitboard, color);
    	
    	Piece initialPiece = null;
    	Piece finalPiece = null;
    	//System.out.println("LOOOOOOOOOOOOOOOOOOOOOOOOOOL");
    	LinkedList<Move> availableMoves = MoveGenerator.generateMovesForColor(bitboard, color);      
    	for (Move move : availableMoves) {
        	//System.out.println("max-Depth: "+depthleft+" Follow up Move: "+move);
    		    	
    		
    		initialPiece = Bitboard.getPieceAtPosition
    				(bitboard, move.getX());
    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getX()); 
    		finalPiece = Bitboard.getPieceAtPosition(bitboard, move.getY());        	
    		if(finalPiece != null){
    			bitboard = Bitboard.unsetPieceAtPosition(bitboard, finalPiece, move.getY());
    		}
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getY());
    		

    		score = alphaBetaMin(bitboard, Search.invertColor(color), alpha, beta, depthleft - 1 );
    		
    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getY()); 
    		if(finalPiece != null){
    			bitboard = Bitboard.setPieceAtPosition(bitboard, finalPiece, move.getY());
    		}        	
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getX());
    		

    		if( score >= beta ){
    			//System.out.println("BETA CUT OFF MAX");
    			return beta;   // fail hard beta-cutoff
    		}
    		if( score > alpha )
    			alpha = score; // alpha acts like max in MiniMax
    	}
        

    	return alpha;
    }
    	 
    private double alphaBetaMin(long[][] bitboard, int color, double alpha, double beta, int depthleft ) {
    	this.nodes++;

    	if ( depthleft == 0 ) return -Evaluator.evaluate(bitboard, color);
    	
    	LinkedList<Move> availableMoves = MoveGenerator.generateMovesForColor(bitboard, color);      
    	for (Move move : availableMoves) {

        	//System.out.println("min-Depth: "+depthleft+" Follow up Move: "+move);

    		
    		Piece initialPiece = Bitboard.getPieceAtPosition(bitboard, move.getX());
    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getX()); 
    		Piece finalPiece = Bitboard.getPieceAtPosition(bitboard, move.getY());        	
    		if(finalPiece != null){
    			bitboard = Bitboard.unsetPieceAtPosition(bitboard, finalPiece, move.getY());
    		}
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getY());

    		score = alphaBetaMax(bitboard, Search.invertColor(color), alpha, beta, depthleft - 1 );
    	//	move.setScore(score);


    		bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getY()); 
    		if(finalPiece != null){
    			bitboard = Bitboard.setPieceAtPosition(bitboard, finalPiece, move.getY());
    		}        	
    		bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getX());

    		if( score <= alpha ){    			
    			//System.out.println("BETA CUT OFF MIN");
    			return alpha; // fail hard alpha-cutoff
    		}
    		if( score < beta )
    			beta = score; // beta acts like min in MiniMax
    	}
    	return beta;
    }
    
    
//    private long search(long[][] bitboard, int color, int depth, long alpha, long beta) {
//        this.nodes++;
//        
//        /* We are at a leaf, evaluate position. */
//        if (depth <= 0) {
//            return Evaluator.evaluate(bitboard, color);
//        }
//        
//        LinkedList<Move> availableMoves = MoveGenerator.generateMovesForColor(bitboard, color);
//        
//        for (Move move : availableMoves) {
//            //System.out.print("   	 Search Move: " + move + "\n");
//
//        	Piece initialPiece = Bitboard.getPieceAtPosition(bitboard, move.getX());
//        	bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getX()); 
//        	Piece finalPiece = Bitboard.getPieceAtPosition(bitboard, move.getY());        	
//        	if(finalPiece != null){
//        		bitboard = Bitboard.unsetPieceAtPosition(bitboard, finalPiece, move.getY());
//        	}
//        	bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getY());
//            
//            long score = -search(bitboard, Search.invertColor(color), depth - 1, -beta, -alpha);
//            
//            if (score > alpha) {
//                alpha = score;
//            }
//            
//        	bitboard = Bitboard.unsetPieceAtPosition(bitboard, initialPiece, move.getY()); 
//        	if(finalPiece != null){
//        		bitboard = Bitboard.setPieceAtPosition(bitboard, finalPiece, move.getY());
//        	}        	
//        	bitboard = Bitboard.setPieceAtPosition(bitboard, initialPiece, move.getX());
//            
//            if (beta <= alpha) {
//                break;
//            }
//        }
//        
//        return alpha;
//    }
    
    private static int invertColor(int color) {
        if (color != Piece.Color.WHITE) {
            return Piece.Color.WHITE;
        } else {
            return Piece.Color.BLACK;
        }
    }
}