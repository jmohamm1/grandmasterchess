package com.yakubvision.deepyellow;



import com.boardgame.ai.Search;
import com.boardgame.engine.ChessGameModel;
import com.boardgame.engine.Move;
import com.chess.grandmasterchess2011.view.ChessGraphicalView;

public class AIController {

	private ChessGameModel model;
	private Search ai;
	private int color;
	
	private static final int DIFFICULTY_DEPTH = 4;

	public AIController(ChessGameModel model, ChessGraphicalView view, int color){
		this.model = model;
		ai = new Search(model,DIFFICULTY_DEPTH);
		this.color = color;
	}
	
	public void move(){
		System.out.println("Data Scientist thinking...");
		Move aiMove = ai.searchForMove(model.getBitboard(), color);
		
		System.out.println("Best move: " + aiMove);
		model.run(aiMove);
	}
	
}
