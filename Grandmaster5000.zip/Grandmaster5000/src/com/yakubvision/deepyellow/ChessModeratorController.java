package com.yakubvision.deepyellow;

import com.boardgame.engine.ChessGameModel;
import com.chess.grandmasterchess2011.view.ChessGraphicalView;

/**
 * 
 * @author Junaid
 *
 */
public class ChessModeratorController {

	private static final int TWO_COMPUTER_DELAY = 1000;
	private static final int ONE_COMPUTER_DELAY = 500;

	
	private ChessGameModel model;
	private ChessGraphicalView view;
	
	private ChessPlayerController controller;
	private ChessPlayerController controller2;

	private AIController computerController;
	//private AIController computerController2;
	
	private boolean onePlayerMode;
	private boolean twoPlayersMode;
	private boolean twoComputersMode;

	/**
	 * 
	 * @param model
	 * @param view
	 */
	public ChessModeratorController(ChessGameModel model, ChessGraphicalView view) {
		this.model = model;
		this.view = view;
		
		//view.addPlayerSetupListener(this);
		
		onePlayerMode = false;
		twoPlayersMode = false;
		twoComputersMode = false;
		
		oneHumanPlayer();
		//twoHumanPlayers();
		//twoComputerPlayers();
	}
	
	public void twoHumanPlayers(){
		twoPlayersMode = true;
		//controller = new ChessPlayerController(this, model, (ChessGraphicalView) view);
		//controller2 = new ChessPlayerController(this, model, (ChessGraphicalView) view, ChessPlayer.BLACK);

		((ChessGraphicalView) view).startGame();
	}
	
	/*public void twoComputerPlayers(){
		twoComputersMode = true;
		computerController = new AIController(this, model, (ChessGraphicalView) view, ChessPlayer.WHITE);
		computerController2 = new AIController(this, model, (ChessGraphicalView) view, ChessPlayer.BLACK);
		((ChessGraphicalView) view).startGame();
		
		//kickstart white
		computerController.move();

	}*/
	
	public void oneHumanPlayer(){
		onePlayerMode = true;
		controller = new ChessPlayerController(this, model, (ChessGraphicalView) view);
		
		class SimpleThread extends Thread {
			

			public SimpleThread(String str){
				super(str);
				computerController = new AIController(model, (ChessGraphicalView) view, 0); //0=black			
			}

			public void run(){
				while(true){
					while(confirmMove){
						computerController.move();
						System.out.println("Grand Master moved!");
						confirmMove = false;
					}
				}
			}
		}		
		Thread t = new SimpleThread("test");
		t.start();
	}	
	
	boolean confirmMove = false;
	
	public void confirmMove(){
		computerController.move();
		System.out.println("Grand Master moved!");
		confirmMove = false;
	}
	
//	public void confirmMove(){		
//		if(onePlayerMode){		
//			delay(ONE_COMPUTER_DELAY);
//			//computerController.move();
//		}
//		else if(twoPlayersMode){
//			//NEED TO IMPLEMENT turn control?
//		}
//		System.out.println("Grand Master moved!");
//	}
	
	private void delay(int delay){
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	

	
	/**public void confirmMove(AIController controller){
		if(twoComputersMode){			
			delay(TWO_COMPUTER_DELAY);
			
			if(controller == computerController){
				computerController2.move();
				System.out.println("Grand Master2 moved!");
			}
			else if(controller == computerController2){
				computerController.move();
				System.out.println("Grand Master moved!");
			}
		}
	}*/

	//@Override
	/**
	 * 
	 */
//	public void actionPerformed(ActionEvent e) {
//				
//		JButton button = (JButton) e.getSource();
//		String label = button.getText();
//		
//		if(label.equals(MainMenuView.ONE_PLAYER)){
//			oneHumanPlayer();
//		}
//		else if(label.equals(MainMenuView.TWO_PLAYERS)){
//			twoHumanPlayers();
//		}
//		else if(label.equals(MainMenuView.TWO_COMPUTERS)){
//			twoComputerPlayers();
//		}
//		
//		//add more here
//		
//	}

}
