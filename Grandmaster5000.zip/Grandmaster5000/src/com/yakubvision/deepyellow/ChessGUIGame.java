package com.yakubvision.deepyellow;

import com.boardgame.engine.ChessGameModel;
import com.chess.grandmasterchess2011.view.ChessGraphicalView;

public class ChessGUIGame {

	//TODO create different setting methods here
	//TODO create different constructors for different settingss
	
	public static void main(String[] args){
		ChessGameModel model = new ChessGameModel();
		ChessGraphicalView view = new ChessGraphicalView(model);
		model.addObserver(view);
				
		//TODO the player will choose the which side (color) 
		//that he wants to play through the view
		
		//the model will save which color the 
		//player chose and the controller can ask for it
		
		
		//menu controller
		//takes user input and creates the appropriate controllers (human/computer)
		//ChessModeratorController mainController = new ChessModeratorController(model, view);
		
		//here i need to init view!!!
		ChessModeratorController mainController = new ChessModeratorController(model, view);  
		view.startGame();
		
		//TODO add a black vertical border to separate the  blocks in view
		
	}
}
