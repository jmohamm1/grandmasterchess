package com.yakubvision.deepyellow;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.boardgame.engine.ChessGameModel;
import com.boardgame.engine.Move;
import com.boardgame.engine.MoveValidator;
import com.boardgame.engine.Position;
import com.chess.grandmasterchess2011.view.ChessGraphicalView;
import com.chess.grandmasterchess2011.view.PositionButton;

/**
 * 
 * @author Junaid
 *
 */
public class ChessPlayerController implements ActionListener {
	
	//private AIController computerController;
	private MoveValidator moveValidator;
	private ChessModeratorController mainController;
	
	protected ChessGameModel model;
	protected ChessGraphicalView view;
	//protected boolean color;

	/**
	 * 
	 * @param model
	 * @param view
	 * @param color
	 */
	public ChessPlayerController(ChessModeratorController mainController, ChessGameModel model, ChessGraphicalView view){
		this.model = model;
		this.view = view;
		//this.color = color;
		this.mainController = mainController;
		view.addGridListener(this);
		
		moveValidator = new MoveValidator(model);
		model.setGameStart(true);
	}	

	@Override
	/**
	 * 
	 */
	public void actionPerformed(ActionEvent e) {
		PositionButton button = (PositionButton) e.getSource(); 
		Position pos = button.getPosition();         

		boolean result = moveValidator.isValidMove(pos);
		if(result){
			Move move = moveValidator.getMove();
			model.run(move);
			System.out.println("BUTTON CLICKED " + pos);
			mainController.confirmMove();

        //TODO concurrency control needs to occur in model 
        //TODO with color changing - take turns!!!!!!!!       	        	
        }
	}	

}
